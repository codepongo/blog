#!/bin/env python
#-*- coding: utf-8 -*-
import sys
import codecs
def debug():
    import pdb
    pdb.set_trace()
if __name__ == '__main__':
    #debug()
    i = last_i = 0
    t = codecs.open(sys.argv[1], 'r', 'utf8')
    hf = sys.argv[1].replace('.txt', '.html', 1)
    h = codecs.open(hf, 'w', 'utf8')
    h.write('''<html>
  <meta http-equiv="content-type" content="text/html; charset=UTF-8">
  <head></head>
  <body>''')

    for line in t:
        #print(line)       
        i = 0;
        while True:
            if ' ' == line[i]:
                i += 1
            else:
                break
        
        if (-1 != line.find('* ')):
            if i > last_i:
                h.write((' ' * last_i) + '<dir>\n')
            elif i < last_i:
                for x in range(((last_i-i)//2)):
                    h.write((' ' * ((i-x)*2)) + '</dir>\n')
            last_i = i
        #line = line[:i]+'<li>'+line[i:]
            line = line.replace('* ', '<li>', 1) 
        else:
            line = '<p>'+line[:len(line)-1]+'</p>'+line[len(line):]
        h.write(line)
    h.write('</body>\n'\
            '</html>\n')
    t.close()
    h.close()
